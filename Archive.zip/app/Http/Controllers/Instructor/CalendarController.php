<?php

namespace App\Http\Controllers\Instructor;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\Booking;
use App\Models\Availability;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\DB;

class CalendarController extends Controller
{
    /**
     * Show the instructor calendar dashboard
     */
    public function index()
    {
        try {
            $instructor = auth()->user()->instructor;
            
            // Get the current date for "today" reference
            $today = Carbon::today();
            
            // Initialize empty collections to avoid undefined variable errors
            $bookings = collect();
            $availabilities = collect();
            
            return view('instructor.calendar.index', compact('today', 'bookings', 'availabilities'));
            
        } catch (\Exception $e) {
            Log::error('Calendar Error: ' . $e->getMessage());
            return back()->with('error', 'Error loading calendar data');
        }
    }
    
    /**
     * Get calendar data (availabilities and bookings) for AJAX requests
     */
    public function getCalendarData()
    {
        try {
            $instructor = auth()->user()->instructor;
            
            // Fetch data for current and next 2 months
            $startDate = Carbon::now()->startOfMonth();
            $endDate = Carbon::now()->addMonths(2)->endOfMonth();
            
            // Get availabilities
            $availabilities = Availability::where('instructor_id', $instructor->id)
                ->whereBetween('date', [$startDate->format('Y-m-d'), $endDate->format('Y-m-d')])
                ->orderBy('date')
                ->orderBy('start_time')
                ->get()
                ->map(function($availability) {
                    return [
                        'id' => $availability->id,
                        'date' => $availability->date->format('Y-m-d'),
                        'start_time' => $availability->start_time,
                        'end_time' => $availability->end_time,
                    ];
                });
            
            // Get bookings
            $bookings = Booking::where('instructor_id', $instructor->id)
                ->whereBetween('date', [$startDate->format('Y-m-d'), $endDate->format('Y-m-d')])
                ->with(['user', 'service', 'suburb'])
                ->orderBy('date')
                ->orderBy('start_time')
                ->get()
                ->map(function($booking) {
                    return [
                        'id' => $booking->id,
                        'date' => $booking->date->format('Y-m-d'),
                        'start_time' => $booking->start_time,
                        'end_time' => $booking->end_time,
                        'status' => $booking->status,
                        'user' => [
                            'id' => $booking->user->id,
                            'name' => $booking->user->name
                        ],
                        'service' => [
                            'id' => $booking->service->id,
                            'name' => $booking->service->name
                        ],
                        'suburb' => $booking->suburb ? [
                            'id' => $booking->suburb->id,
                            'name' => $booking->suburb->name
                        ] : null
                    ];
                });
                
            return response()->json([
                'availabilities' => $availabilities,
                'bookings' => $bookings
            ]);
            
        } catch (\Exception $e) {
            Log::error('Calendar Data Error: ' . $e->getMessage());
            return response()->json(['error' => 'Failed to load calendar data'], 500);
        }
    }
    
    /**
     * Show availability management page for the instructor
     */
    public function availability(Request $request)
    {
        // Get month parameter or default to current month
        $monthParam = $request->query('month');
        
        if ($monthParam) {
            try {
                $viewMonth = Carbon::createFromFormat('Y-m', $monthParam);
            } catch (\Exception $e) {
                $viewMonth = now();
            }
        } else {
            $viewMonth = now();
        }
        
        // Set start and end dates for calendar display
        $startDate = $viewMonth->copy()->startOfMonth()->startOfWeek();
        $endDate = $viewMonth->copy()->endOfMonth()->endOfWeek();
        
        // Navigation variables
        $prevMonth = $viewMonth->copy()->subMonth()->format('Y-m');
        $nextMonth = $viewMonth->copy()->addMonth()->format('Y-m');
        
        $instructor = auth()->user()->instructor;
        
        // Get the current date for "today" reference
        $today = Carbon::today();

        // Fetch availabilities for the instructor (for the current view period)
        $availabilities = Availability::where('instructor_id', $instructor->id)
            ->whereBetween('date', [$startDate->format('Y-m-d'), $endDate->format('Y-m-d')])
            ->orderBy('date')
            ->orderBy('start_time')
            ->get();
        
        // Group availabilities by date for easier use in template
        $groupedAvailabilities = $availabilities->groupBy(function($availability) {
            return $availability->date->format('Y-m-d');
        });

        return view('instructor.calendar.availability', compact(
            'availabilities', 
            'today',
            'viewMonth',
            'startDate',
            'endDate',
            'prevMonth',
            'nextMonth',
            'groupedAvailabilities'
        ));
    }
    
    /**
     * Store a new availability
     */
    public function storeAvailability(Request $request)
    {
        $validated = $request->validate([
            'date' => 'required|date|after_or_equal:today',
            'start_time' => 'required|date_format:H:i',
            'end_time' => 'required|date_format:H:i|after:start_time',
            'is_recurring' => 'sometimes|boolean',
            'recur_until' => 'required_if:is_recurring,1|nullable|date|after:date',
            'days_of_week' => 'required_if:is_recurring,1|array',
            'days_of_week.*' => 'integer|min:0|max:6',
        ]);

        DB::beginTransaction();
        
        try {
            $instructor = auth()->user()->instructor;
            
            // If this is a recurring availability
            if (isset($validated['is_recurring']) && $validated['is_recurring']) {
                $startDate = Carbon::parse($validated['date']);
                $endDate = Carbon::parse($validated['recur_until']);
                $daysOfWeek = $validated['days_of_week'];
                
                // Loop through each day from start to end date
                for ($date = $startDate; $date->lte($endDate); $date->addDay()) {
                    // Check if this day of the week is selected
                    if (in_array($date->dayOfWeek, $daysOfWeek)) {
                        // Create availability for this date
                        Availability::create([
                            'instructor_id' => $instructor->id,
                            'date' => $date->format('Y-m-d'),
                            'start_time' => $validated['start_time'],
                            'end_time' => $validated['end_time'],
                        ]);
                    }
                }
            } else {
                // Create a single availability
                Availability::create([
                    'instructor_id' => $instructor->id,
                    'date' => $validated['date'],
                    'start_time' => $validated['start_time'],
                    'end_time' => $validated['end_time'],
                ]);
            }
            
            DB::commit();
            
            return redirect()->back()->with('success', 'Availability added successfully.');
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Error adding availability: ' . $e->getMessage());
            return back()->with('error', 'Error adding availability: ' . $e->getMessage());
        }
    }
    
    /**
     * Delete an availability
     */
    public function destroyAvailability($availabilityId)
    {
        $instructor = auth()->user()->instructor;
        
        $availability = Availability::where('instructor_id', $instructor->id)
            ->findOrFail($availabilityId);
        
        try {
            $availability->delete();
            return redirect()->back()->with('success', 'Availability removed successfully.');
        } catch (\Exception $e) {
            Log::error('Error removing availability: ' . $e->getMessage());
            return back()->with('error', 'Error removing availability: ' . $e->getMessage());
        }
    }
    
    /**
     * Get booking details 
     */
    public function getBookingDetails($bookingId)
    {
        try {
            $instructor = auth()->user()->instructor;
            
            $booking = Booking::where('instructor_id', $instructor->id)
                ->where('id', $bookingId)
                ->with(['user', 'service', 'suburb'])
                ->firstOrFail();
                
            return response()->json($booking);
        } catch (\Exception $e) {
            Log::error('Error getting booking details: ' . $e->getMessage());
            return response()->json(['error' => 'Booking not found'], 404);
        }
    }
}
