<?php
namespace App\Http\Controllers\Instructor;

use App\Http\Controllers\Controller;
use App\Models\Availability;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class AvailabilityController extends Controller
{
    /**
     * Display the instructor's availability calendar
     */
    public function index(Request $request)
    {
        $instructor = Auth::user()->instructor;

        try {
            // Set up calendar dates
            $today = Carbon::today();
            $viewMonth = $this->getViewMonth($request, $today);
            $calendarDates = $this->getCalendarDates($viewMonth);

            // Get availabilities for the date range
            $availabilities = $this->getAvailabilities(
                $instructor->id,
                $calendarDates['startDate'],
                $calendarDates['endDate']
            );

            $services = \App\Models\Service::where('active', true)->get();
            return view('instructor.availability.index', [
                'groupedAvailabilities' => $availabilities->groupBy(function($item) {
                    return $item->date->format('Y-m-d');
                }),
                'startDate' => $calendarDates['startDate'],
                'endDate' => $calendarDates['endDate'],
                'prevMonth' => $viewMonth->copy()->subMonth()->format('Y-m'),
                'nextMonth' => $viewMonth->copy()->addMonth()->format('Y-m'),
                'currentMonth' => $viewMonth->format('Y-m'),
                'viewMonth' => $viewMonth,
                'weeks' => $calendarDates['weeks'],
                'services' => $services,
            ]);

        } catch (\Exception $e) {
            Log::error('Error displaying calendar: ' . $e->getMessage());
            return back()->with('error', 'Error displaying calendar');
        }
    }

    /**
     * Store a new availability slot
     */
    public function store(Request $request)
    {
        $instructor = Auth::user()->instructor;

        $validated = $request->validate([
            'date' => 'required|date|after_or_equal:today',
            'start_time' => 'required|date_format:H:i',
            'end_time' => 'required|date_format:H:i|after:start_time',
            'is_recurring' => 'nullable|boolean',
            'recur_until' => 'nullable|required_if:is_recurring,1|date|after:date',
            'days_of_week' => 'nullable|required_if:is_recurring,1|array',
            'days_of_week.*' => 'nullable|integer|between:0,6',
        ]);

        DB::beginTransaction();

        try {
            $dates = $this->calculateDateRange($validated);
            $daysOfWeek = $this->getDaysOfWeek($request, $validated, $dates['startDate']);

            $createdCount = 0;
            $currentDate = $dates['startDate']->copy();

            while ($currentDate->lte($dates['endDate'])) {
                if (in_array((int)$currentDate->dayOfWeek, $daysOfWeek)) {
                    // Create 15-minute interval slots
                    $startTime = Carbon::parse($validated['start_time']);
                    $endTime = Carbon::parse($validated['end_time']);
                    
                    while ($startTime->lt($endTime)) {
                        $slotEndTime = $startTime->copy()->addMinutes(15);
                        
                        // Don't create a slot that would exceed the end time
                        if ($slotEndTime->gt($endTime)) {
                            break;
                        }
                        
                        // Check if this exact slot already exists
                        $existingSlot = Availability::where('instructor_id', $instructor->id)
                            ->where('date', $currentDate->format('Y-m-d'))
                            ->where('start_time', $startTime->format('H:i:s'))
                            ->where('end_time', $slotEndTime->format('H:i:s'))
                            ->first();
                        
                        if (!$existingSlot) {
                            Availability::create([
                                'instructor_id' => $instructor->id,
                                'date' => $currentDate->format('Y-m-d'),
                                'start_time' => $startTime->format('H:i:s'),
                                'end_time' => $slotEndTime->format('H:i:s'),
                                'is_available' => true
                            ]);
                            $createdCount++;
                        }
                        
                        $startTime = $slotEndTime;
                    }
                }
                $currentDate->addDay();
            }

            DB::commit();

            return redirect()->route('instructor.availability.index')
                ->with('success', "{$createdCount} availability slots created successfully");

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Error creating availability: ' . $e->getMessage());
            return back()->with('error', 'Error creating availability slots: ' . $e->getMessage());
        }
    }

    /**
     * Delete an availability slot
     */
    public function destroy(Availability $availability)
    {
        if (!$this->canModifyAvailability($availability)) {
            abort(403);
        }

        if ($availability->isBooked()) {
            return back()->with('error', 'Cannot delete availability with existing bookings');
        }

        $availability->delete();
        return back()->with('success', 'Availability slot deleted successfully');
    }

    /**
     * Bulk delete availability slots
     */
    public function bulkDelete(Request $request)
    {
        $instructor = Auth::user()->instructor;

        $validated = $request->validate([
            'date' => 'required|date',
            'delete_all_future' => 'nullable|boolean',
        ]);

        try {
            $query = $this->buildBulkDeleteQuery($instructor->id, $validated);

            if ($this->hasBookings($query)) {
                return back()->with('error', 'Cannot delete slots with existing bookings');
            }

            $count = $query->count();
            $query->delete();

            return back()->with('success', "{$count} availability slots deleted successfully");

        } catch (\Exception $e) {
            Log::error('Error deleting availability: ' . $e->getMessage());
            return back()->with('error', 'Error deleting availability slots');
        }
    }

    // --- Private helper methods ---

    private function getViewMonth(Request $request, Carbon $today)
    {
        if (!$request->has('month')) {
            return $today->copy();
        }

        try {
            return Carbon::createFromFormat('Y-m', $request->month)->startOfMonth();
        } catch (\Exception $e) {
            Log::warning('Invalid month format provided: ' . $request->month);
            return $today->copy();
        }
    }

    private function getCalendarDates(Carbon $viewMonth)
    {
        $startDate = $viewMonth->copy()->startOfMonth()->startOfWeek(Carbon::SUNDAY);
        $endDate = $viewMonth->copy()->endOfMonth()->endOfWeek(Carbon::SATURDAY);

        $weeks = [];
        $currentDate = $startDate->copy();

        while ($currentDate->lte($endDate)) {
            $week = [];
            for ($i = 0; $i < 7 && $currentDate->lte($endDate); $i++) {
                $week[] = $currentDate->copy();
                $currentDate->addDay();
            }
            $weeks[] = $week;
        }

        return compact('startDate', 'endDate', 'weeks');
    }

    private function getAvailabilities($instructorId, Carbon $startDate, Carbon $endDate)
    {
        return Availability::where('instructor_id', $instructorId)
            ->whereDate('date', '>=', $startDate)
            ->whereDate('date', '<=', $endDate)
            ->orderBy('date')
            ->orderBy('start_time')
            ->get();
    }

    private function calculateDateRange(array $validated)
    {
        $startDate = Carbon::parse($validated['date']);
        $endDate = isset($validated['recur_until']) ? Carbon::parse($validated['recur_until']) : $startDate;

        return compact('startDate', 'endDate');
    }

    private function getDaysOfWeek(Request $request, array $validated, Carbon $startDate)
    {
        return $request->has('is_recurring') && isset($validated['days_of_week'])
            ? array_map('intval', $validated['days_of_week'])
            : [(int)$startDate->dayOfWeek];
    }

    private function canModifyAvailability(Availability $availability)
    {
        return $availability->instructor_id === Auth::user()->instructor->id;
    }

    private function buildBulkDeleteQuery($instructorId, array $validated)
    {
        $query = Availability::where('instructor_id', $instructorId);

        if (!empty($validated['delete_all_future'])) {
            $query->whereDate('date', '>=', $validated['date']);
        } else {
            $query->whereDate('date', $validated['date']);
        }

        return $query;
    }

    private function hasBookings($query)
    {
        return $query->get()->some(function($availability) {
            return $availability->isBooked();
        });
    }
}