<?php

namespace App\Notifications;

use App\Models\Booking;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use Carbon\Carbon;

class NewBookingReceived extends Notification implements ShouldQueue
{
    use Queueable;

    protected $booking;

    /**
     * Create a new notification instance.
     */
    public function __construct(Booking $booking)
    {
        $this->booking = $booking;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @return array<int, string>
     */
    public function via(object $notifiable): array
    {
        return ['mail', 'database'];
    }

    /**
     * Get the mail representation of the notification.
     */
    public function toMail(object $notifiable): MailMessage
    {
        $date = Carbon::parse($this->booking->date)->format('l, F j, Y');
        $startTime = Carbon::parse($this->booking->start_time)->format('g:i A');
        $endTime = Carbon::parse($this->booking->end_time)->format('g:i A');
        
        return (new MailMessage)
            ->subject('New Booking Received - Wave Driving School')
            ->greeting('Hello ' . $notifiable->name . ',')
            ->line('You have received a new booking request.')
            ->line('**Student:** ' . $this->booking->user->name)
            ->line('**Service:** ' . $this->booking->service->name)
            ->line('**Date:** ' . $date)
            ->line('**Time:** ' . $startTime . ' - ' . $endTime)
            ->line('**Location:** ' . $this->booking->suburb->name)
            ->line('**Pickup Address:** ' . $this->booking->address)
            ->action('View Booking Details', url('/instructor/bookings/' . $this->booking->id))
            ->line('Please confirm this booking at your earliest convenience.');
    }

    /**
     * Get the array representation of the notification.
     *
     * @return array<string, mixed>
     */
    public function toDatabase(object $notifiable): array
    {
        return [
            'booking_id' => $this->booking->id,
            'title' => 'New Booking Request',
            'message' => 'You have received a new booking from ' . $this->booking->user->name,
            'date_time' => Carbon::parse($this->booking->date)->format('M d, Y') . ' at ' . Carbon::parse($this->booking->start_time)->format('g:i A'),
            'student_name' => $this->booking->user->name,
            'icon' => 'bx-calendar-plus',
            'color' => 'info',
            'link' => '/instructor/bookings/' . $this->booking->id
        ];
    }
}