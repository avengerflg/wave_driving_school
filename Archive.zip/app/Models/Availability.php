<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;

class Availability extends Model
{
    use HasFactory;

    protected $fillable = [
        'instructor_id',
        'date',
        'start_time',
        'end_time',
        'is_available',
        'notes',
    ];

    protected $table = 'availabilities';

    protected $casts = [
        'date' => 'date',
        'is_available' => 'boolean',
    ];

    /**
     * Get the instructor that owns this availability slot.
     */
    public function instructor()
    {
        return $this->belongsTo(Instructor::class);
    }

    /**
     * Get any bookings that overlap with this availability slot.
     */
    public function bookings()
    {
        return Booking::where('instructor_id', $this->instructor_id)
            ->where('date', $this->date)
            ->where(function ($query) {
                $query->where(function ($q) {
                    // Booking starts during availability
                    $q->where('start_time', '>=', $this->start_time)
                        ->where('start_time', '<', $this->end_time);
                })->orWhere(function ($q) {
                    // Booking ends during availability
                    $q->where('end_time', '>', $this->start_time)
                        ->where('end_time', '<=', $this->end_time);
                })->orWhere(function ($q) {
                    // Booking completely overlaps availability
                    $q->where('start_time', '<=', $this->start_time)
                        ->where('end_time', '>=', $this->end_time);
                });
            });
    }

    /**
     * Calculate the duration in minutes.
     */
    public function getDurationAttribute()
    {
        return Carbon::parse($this->start_time)->diffInMinutes(Carbon::parse($this->end_time));
    }

    /**
     * Get a Carbon instance for the start date and time.
     */
    public function getStartDateTimeAttribute()
    {
        return Carbon::parse($this->date->format('Y-m-d') . ' ' . $this->start_time);
    }

    /**
     * Get a Carbon instance for the end date and time.
     */
    public function getEndDateTimeAttribute()
    {
        return Carbon::parse($this->date->format('Y-m-d') . ' ' . $this->end_time);
    }

    /**
     * Format the start time for display.
     */
    public function getFormattedStartTimeAttribute()
    {
        return Carbon::parse($this->start_time)->format('h:i A');
    }

    /**
     * Format the end time for display.
     */
    public function getFormattedEndTimeAttribute()
    {
        return Carbon::parse($this->end_time)->format('h:i A');
    }

    /**
     * Check if this availability slot is booked.
     */
    public function isBooked()
    {
        return $this->bookings()->exists();
    }

    /**
     * Check if this availability slot is in the past.
     */
    public function isPast()
    {
        return $this->start_date_time->isPast();
    }

    /**
     * Check if this availability is available for booking.
     */
    public function isAvailableForBooking()
    {
        return $this->is_available && !$this->isBooked() && !$this->isPast();
    }

    /**
     * Scope a query to only include available slots.
     */
    public function scopeAvailable(Builder $query): Builder
    {
        return $query->where('is_available', true);
    }

    /**
     * Scope a query to only include future availability slots.
     */
    public function scopeFuture(Builder $query): Builder
    {
        return $query->whereDate('date', '>=', Carbon::today());
    }

    /**
     * Scope a query to find availability for a specific instructor in a date range.
     */
    public function scopeAvailableForInstructor($query, $instructorId, $startDate, $endDate)
    {
        return $query->where('instructor_id', $instructorId)
            ->where('date', '>=', $startDate)
            ->where('date', '<=', $endDate)
            ->where('is_available', true)
            ->orderBy('date')
            ->orderBy('start_time');
    }

    /**
     * Scope a query to find availability for a specific date.
     */
    public function scopeOnDate($query, $date)
    {
        return $query->whereDate('date', $date);
    }

    /**
     * Scope a query to find availability slots that are not booked.
     */
    public function scopeNotBooked($query)
    {
        $query->whereDoesntHave('bookings', function($q) {
            $q->where('status', '!=', 'cancelled');
        });
    }

    /**
     * Get available time slots for an instructor on a specific date.
     */
    public static function getAvailableTimeSlotsForDate($instructorId, $date)
    {
        return static::where('instructor_id', $instructorId)
            ->whereDate('date', $date)
            ->where('is_available', true)
            ->orderBy('start_time')
            ->get()
            ->filter(function ($availability) {
                return !$availability->isBooked();
            });
    }
}