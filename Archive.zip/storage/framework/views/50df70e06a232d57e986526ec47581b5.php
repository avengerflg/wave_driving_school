<?php $__env->startSection('title', 'My Calendar'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><i class="bx bx-calendar me-2"></i>My Calendar</h5>
                <a href="<?php echo e(route('instructor.availability.index')); ?>" class="btn btn-primary btn-sm">
                    <i class="bx bx-edit me-1"></i> Manage Availability
                </a>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <!-- Sidebar Calendar -->
    <div class="col-md-4 col-lg-3 mb-4">
        <div class="card h-100">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <button id="prev-month" class="btn btn-sm btn-outline-secondary"><i class="bx bx-chevron-left"></i></button>
                    <h6 id="current-month" class="mb-0 fw-bold"><?php echo e(now()->format('F Y')); ?></h6>
                    <button id="next-month" class="btn btn-sm btn-outline-secondary"><i class="bx bx-chevron-right"></i></button>
                </div>
                <div class="table-responsive">
                    <table class="table table-sm text-center calendar-table mb-0">
                        <thead>
                            <tr class="text-muted small">
                                <th>S</th><th>M</th><th>T</th><th>W</th><th>T</th><th>F</th><th>S</th>
                            </tr>
                        </thead>
                        <tbody id="calendar-body"></tbody>
                    </table>
                </div>
                <div class="mt-3">
                    <div class="d-flex align-items-center mb-1">
                        <span class="badge bg-success-subtle text-success me-2">&nbsp;</span> Available
                    </div>
                    <div class="d-flex align-items-center mb-1">
                        <span class="badge bg-primary-subtle text-primary me-2">&nbsp;</span> Booked
                    </div>
                    <div class="d-flex align-items-center">
                        <span class="badge bg-info-subtle text-info me-2">&nbsp;</span> Partially Booked
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Main Content -->
    <div class="col-md-8 col-lg-9">
        <div class="card">
            <div class="card-body">
                <h5 id="selected-date" class="card-title mb-4"><?php echo e($today->format('l, F j, Y')); ?></h5>
                <div id="timeline" class="timeline-with-icons">
                    <div class="text-center text-muted py-5">
                        <i class="bx bx-calendar-event fs-1 mb-2"></i>
                        <p>Select a date to view availability and bookings</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Booking Details Modal -->
<div class="modal fade" id="booking-details-modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Booking Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="booking-details-content">
                <div class="d-flex justify-content-center py-3">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-scripts'); ?>
<script>
    let currentDate = new Date();
    let selectedDate = new Date();
    let currentMonth = currentDate.getMonth();
    let currentYear = currentDate.getFullYear();
    let availabilities = [];
    let bookings = [];
    let bookingModal;

    // Function to convert HH:MM time to minutes since midnight for easier comparison
    function timeToMinutes(timeStr) {
        const [hours, minutes] = timeStr.split(':').map(Number);
        return hours * 60 + minutes;
    }

    document.addEventListener('DOMContentLoaded', function() {
        // Initialize modal
        bookingModal = new bootstrap.Modal(document.getElementById('booking-details-modal'));
        
        // Initial calendar data
        fetchCalendarData();

        document.getElementById('prev-month').addEventListener('click', function() {
            currentMonth--;
            if (currentMonth < 0) { currentMonth = 11; currentYear--; }
            generateCalendar(currentMonth, currentYear);
        });
        
        document.getElementById('next-month').addEventListener('click', function() {
            currentMonth++;
            if (currentMonth > 11) { currentMonth = 0; currentYear++; }
            generateCalendar(currentMonth, currentYear);
        });
    });

    function fetchCalendarData() {
        fetch('/instructor/calendar/data')
            .then(response => response.json())
            .then(data => {
                if (data.error) {
                    console.error('Error:', data.error);
                    return;
                }
                availabilities = data.availabilities;
                bookings = data.bookings;
                generateCalendar(currentMonth, currentYear);
            })
            .catch(error => {
                console.error('Error fetching calendar data:', error);
            });
    }

    function generateCalendar(month, year) {
        const firstDay = new Date(year, month, 1);
        const lastDay = new Date(year, month + 1, 0);
        const daysInMonth = lastDay.getDate();
        const startingDay = firstDay.getDay();
        const monthNames = ["January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"];
        document.getElementById('current-month').textContent = `${monthNames[month]} ${year}`;
        
        const calendarBody = document.getElementById('calendar-body');
        calendarBody.innerHTML = '';
        let date = 1;
        for (let i = 0; i < 6; i++) {
            const row = document.createElement('tr');
            for (let j = 0; j < 7; j++) {
                const cell = document.createElement('td');
                if (i === 0 && j < startingDay) {
                    const prevMonth = month === 0 ? 11 : month - 1;
                    const prevYear = month === 0 ? year - 1 : year;
                    const prevMonthDays = new Date(prevYear, prevMonth + 1, 0).getDate();
                    const prevDate = prevMonthDays - (startingDay - j - 1);
                    cell.innerHTML = `<span class="text-muted small">${prevDate}</span>`;
                    cell.dataset.date = `${prevYear}-${(prevMonth + 1).toString().padStart(2, '0')}-${prevDate.toString().padStart(2, '0')}`;
                } else if (date > daysInMonth) {
                    const nextDate = date - daysInMonth;
                    const nextMonth = month === 11 ? 0 : month + 1;
                    const nextYear = month === 11 ? year + 1 : year;
                    cell.innerHTML = `<span class="text-muted small">${nextDate}</span>`;
                    cell.dataset.date = `${nextYear}-${(nextMonth + 1).toString().padStart(2, '0')}-${nextDate.toString().padStart(2, '0')}`;
                    date++;
                } else {
                    const dateStr = `${year}-${(month + 1).toString().padStart(2, '0')}-${date.toString().padStart(2, '0')}`;
                    const hasAvailability = availabilities.some(a => a.date === dateStr);
                    const hasBookings = bookings.some(b => b.date === dateStr);
                    
                    let cellClass = 'calendar-day';
                    let badgeClass = '';
                    
                    if (hasAvailability && hasBookings) {
                        badgeClass = 'bg-info-subtle text-info';
                    } else if (hasAvailability) {
                        badgeClass = 'bg-success-subtle text-success';
                    } else if (hasBookings) {
                        badgeClass = 'bg-primary-subtle text-primary';
                    }
                    
                    const today = new Date();
                    const isToday = date === today.getDate() && month === today.getMonth() && year === today.getFullYear();
                    
                    cell.innerHTML = `
                        <button class="btn btn-sm calendar-day-btn ${isToday ? 'border-primary' : ''} ${badgeClass}">
                            ${date}
                        </button>
                    `;
                    cell.dataset.date = dateStr;
                    cell.addEventListener('click', function() {
                        selectDate(dateStr);
                    });
                    date++;
                }
                row.appendChild(cell);
            }
            calendarBody.appendChild(row);
            if (date > daysInMonth) break;
        }
    }

    function selectDate(dateStr) {
        // Update the selected date display
        const date = new Date(dateStr);
        const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        document.getElementById('selected-date').textContent = date.toLocaleDateString('en-US', options);
        
        // Load timeline for the selected date
        loadTimeline(dateStr);
        
        // Highlight the selected date in the calendar
        document.querySelectorAll('.calendar-day-btn.active').forEach(btn => {
            btn.classList.remove('active', 'btn-primary');
        });
        
        const selectedCell = document.querySelector(`[data-date="${dateStr}"] .calendar-day-btn`);
        if (selectedCell) {
            selectedCell.classList.add('active', 'btn-primary');
        }
    }

    function loadTimeline(dateStr) {
        const timeline = document.getElementById('timeline');
        timeline.innerHTML = '';
        const dayAvailabilities = availabilities.filter(a => a.date === dateStr);
        const dayBookings = bookings.filter(b => b.date === dateStr);
        
        if (dayAvailabilities.length === 0 && dayBookings.length === 0) {
            timeline.innerHTML = `
                <div class="text-center text-muted py-5">
                    <i class="bx bx-calendar-x fs-1 mb-2"></i>
                    <p>No availability or bookings for this date</p>
                    <a href="<?php echo e(route('instructor.calendar.availability')); ?>" class="btn btn-primary mt-3">
                        Add Availability
                    </a>
                </div>
            `;
            return;
        }
        
        const allSlots = [];
        dayAvailabilities.forEach(availability => {
            allSlots.push({ type: 'availability', data: availability, startTime: availability.start_time, endTime: availability.end_time });
        });
        dayBookings.forEach(booking => {
            allSlots.push({ type: 'booking', data: booking, startTime: booking.start_time, endTime: booking.end_time });
        });
        
        allSlots.sort((a, b) => a.startTime.localeCompare(b.startTime));
        
        allSlots.forEach((slot, index) => {
            const timeSlot = document.createElement('div');
            timeSlot.classList.add('timeline-item', 'pb-3', 'mb-3', 'border-start', 'ps-3');
            
            if (slot.type === 'availability') {
                // Check if this availability slot overlaps with any booking
                const isBooked = dayBookings.some(booking => {
                    // Convert times to comparable values (minutes since midnight)
                    const availStart = timeToMinutes(slot.startTime);
                    const availEnd = timeToMinutes(slot.endTime);
                    const bookStart = timeToMinutes(booking.start_time);
                    const bookEnd = timeToMinutes(booking.end_time);
                    
                    // Check for any overlap between booking and availability
                    return (bookStart < availEnd && bookEnd > availStart);
                });
                
                if (isBooked) {
                    timeSlot.classList.add('border-secondary');
                    timeSlot.innerHTML = `
                        <div class="timeline-icon bg-secondary shadow-sm">
                            <i class="bx bx-time-five"></i>
                        </div>
                        <div class="card border-0 shadow-sm">
                            <div class="card-body py-2">
                                <h6 class="mb-1">${formatTime(slot.startTime)} - ${formatTime(slot.endTime)}</h6>
                                <p class="text-muted small mb-0">This slot is already booked</p>
                            </div>
                        </div>
                    `;
                } else {
                    timeSlot.classList.add('border-success');
                    timeSlot.innerHTML = `
                        <div class="timeline-icon bg-success shadow-sm">
                            <i class="bx bx-check"></i>
                        </div>
                        <div class="card border-0 shadow-sm">
                            <div class="card-body py-2">
                                <h6 class="mb-1">${formatTime(slot.startTime)} - ${formatTime(slot.endTime)}</h6>
                                <p class="text-success small mb-0">Available</p>
                            </div>
                        </div>
                    `;
                }
            } else {
                // This is an existing booking
                timeSlot.classList.add('border-primary');
                timeSlot.innerHTML = `
                    <div class="timeline-icon bg-primary shadow-sm">
                        <i class="bx bx-calendar-check"></i>
                    </div>
                    <div class="card border-0 shadow-sm">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <h6 class="mb-0">${formatTime(slot.startTime)} - ${formatTime(slot.endTime)}</h6>
                                <span class="badge ${getStatusBadgeClass(slot.data.status)}">${slot.data.status}</span>
                            </div>
                            <p class="mb-1"><strong>${slot.data.service.name}</strong></p>
                            <p class="text-muted small mb-2">Student: ${slot.data.user.name}</p>
                            <button type="button" class="btn btn-sm btn-outline-primary" onclick="viewBookingDetails(${slot.data.id})">
                                <i class="bx bx-info-circle me-1"></i> Details
                            </button>
                        </div>
                    </div>
                `;
            }
            timeline.appendChild(timeSlot);
        });
    }

    function formatTime(time) {
        const [hours, minutes] = time.split(':');
        const hour = parseInt(hours);
        const ampm = hour >= 12 ? 'PM' : 'AM';
        const hour12 = hour % 12 || 12;
        return `${hour12}:${minutes} ${ampm}`;
    }

    function getStatusBadgeClass(status) {
        switch(status.toLowerCase()) {
            case 'confirmed':
                return 'bg-success';
            case 'cancelled':
                return 'bg-danger';
            case 'completed':
                return 'bg-info';
            default:
                return 'bg-secondary';
        }
    }

    function viewBookingDetails(bookingId) {
        // Show the modal
        bookingModal.show();
        
        // Reset content to loading state
        document.getElementById('booking-details-content').innerHTML = `
            <div class="d-flex justify-content-center py-3">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
            </div>
        `;
        
        // Fetch booking details
        fetch(`/instructor/calendar/booking/${bookingId}`)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Booking not found');
                }
                return response.json();
            })
            .then(booking => {
                document.getElementById('booking-details-content').innerHTML = `
                    <div class="mb-3 d-flex justify-content-between align-items-center">
                        <h6 class="mb-0">Booking #${booking.id}</h6>
                        <span class="badge ${getStatusBadgeClass(booking.status)}">${booking.status}</span>
                    </div>
                    
                    <div class="mb-3">
                        <div class="mb-2 d-flex align-items-center">
                            <i class="bx bx-calendar me-2 text-muted"></i>
                            <span>${formatDate(booking.date)}</span>
                        </div>
                        <div class="mb-2 d-flex align-items-center">
                            <i class="bx bx-time me-2 text-muted"></i>
                            <span>${formatTime(booking.start_time)} - ${formatTime(booking.end_time)}</span>
                        </div>
                        <div class="mb-2 d-flex align-items-center">
                            <i class="bx bx-user me-2 text-muted"></i>
                            <span>${booking.user.name}</span>
                        </div>
                        <div class="mb-2 d-flex align-items-center">
                            <i class="bx bx-purchase-tag me-2 text-muted"></i>
                            <span>${booking.service.name}</span>
                        </div>
                        ${booking.suburb ? `
                        <div class="mb-2 d-flex align-items-center">
                            <i class="bx bx-map me-2 text-muted"></i>
                            <span>${booking.suburb.name}</span>
                        </div>
                        ` : ''}
                    </div>
                    
                    ${booking.notes ? `
                    <div class="mt-3">
                        <h6 class="mb-2">Notes:</h6>
                        <div class="p-3 bg-light rounded">${booking.notes}</div>
                    </div>
                    ` : ''}
                `;
            })
            .catch(error => {
                document.getElementById('booking-details-content').innerHTML = `
                    <div class="text-center text-danger py-3">
                        <i class="bx bx-error-circle fs-1 mb-2"></i>
                        <p>Error loading booking details</p>
                    </div>
                `;
                console.error('Error fetching booking details:', error);
            });
    }

    function formatDate(dateStr) {
        const date = new Date(dateStr);
        return date.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
    }
</script>

<style>
    .calendar-table {
        table-layout: fixed;
    }
    
    .calendar-table td {
        padding: 2px;
        text-align: center;
        height: 2.5rem;
        width: 14.28%;
    }
    
    .calendar-day-btn {
        width: 28px !important;
        height: 28px !important;
        padding: 0 !important;
        border-radius: 50% !important;
        display: inline-flex !important;
        align-items: center !important;
        justify-content: center !important;
        font-size: 0.75rem !important;
    }
    
    .timeline-with-icons {
        position: relative;
        padding-left: 1.5rem;
    }
    
    .timeline-item {
        position: relative;
        border-left-width: 2px !important;
    }
    
    .timeline-icon {
        position: absolute;
        left: -11px;
        top: 0;
        width: 20px;
        height: 20px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
        font-size: 12px;
    }
    
    /* Media queries for responsiveness */
    @media (max-width: 767.98px) {
        .calendar-day-btn {
            width: 24px !important;
            height: 24px !important;
            font-size: 0.7rem !important;
        }
        
        .calendar-table th {
            font-size: 0.7rem;
        }
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.instructor', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/rishikumar/Desktop/developement/wavedriving/resources/views/instructor/calendar/index.blade.php ENDPATH**/ ?>