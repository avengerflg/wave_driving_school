<?php $__env->startSection('title', 'My Clients'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
    <!-- Header -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <h4 class="fw-bold m-0">
                            <i class="bx bx-user-circle text-primary me-2"></i>
                            My Clients
                        </h4>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Search and Filter -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('instructor.clients.index')); ?>" class="row g-3">
                <div class="col-md-6">
                    <div class="input-group">
                        <span class="input-group-text"><i class="bx bx-search"></i></span>
                        <input type="text" name="search" class="form-control" placeholder="Search clients..." value="<?php echo e($search ?? ''); ?>">
                    </div>
                </div>
                <div class="col-md-4">
                    <select name="status" class="form-select">
                        <option value="">All Status</option>
                        <option value="active" <?php echo e(request('status') == 'active' ? 'selected' : ''); ?>>Active</option>
                        <option value="inactive" <?php echo e(request('status') == 'inactive' ? 'selected' : ''); ?>>Inactive</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">Search</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Clients List -->
    <div class="card">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Client</th>
                        <th>Contact</th>
                        <th>Total Lessons</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <div class="d-flex align-items-center">
                                <div class="avatar avatar-sm me-3">
                                    <?php if($client->profile_image): ?>
                                        <img src="<?php echo e(Storage::url($client->profile_image)); ?>" alt="Avatar" class="rounded-circle">
                                    <?php else: ?>
                                        <span class="avatar-initial rounded-circle bg-primary">
                                            <?php echo e(substr($client->name, 0, 1)); ?>

                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div>
                                    <h6 class="mb-0"><?php echo e($client->name); ?></h6>
                                    <small class="text-muted">Since <?php echo e($client->created_at->format('M Y')); ?></small>
                                </div>
                            </div>
                        </td>
                        <td>
                            <div><?php echo e($client->email); ?></div>
                            <small class="text-muted"><?php echo e($client->phone ?? 'No phone'); ?></small>
                        </td>
                        <td>
                            <span class="badge bg-label-primary"><?php echo e($client->bookings_count); ?> lessons</span>
                        </td>
                        <td>
                            <span class="badge bg-label-<?php echo e($client->status === 'active' ? 'success' : 'warning'); ?>">
                                <?php echo e(ucfirst($client->status)); ?>

                            </span>
                        </td>
                        <td>
                            <a href="<?php echo e(route('instructor.clients.show', $client)); ?>" class="btn btn-sm btn-primary">
                                <i class="bx bx-show-alt me-1"></i> View Details
                            </a>
                            <a href="<?php echo e(route('instructor.clients.bookings', $client)); ?>" class="btn btn-sm btn-outline-primary">
                                <i class="bx bx-calendar me-1"></i> Bookings
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center py-4">
                            <div class="text-center">
                                <i class="bx bx-user-x text-secondary mb-2" style="font-size: 3rem;"></i>
                                <h6 class="mb-0 text-secondary">No clients found</h6>
                                <p class="text-muted mb-0">You haven't had any lessons with clients yet</p>
                            </div>
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Pagination -->
    <?php if($clients->hasPages()): ?>
    <div class="card mt-4">
        <div class="card-body">
            <?php echo e($clients->links()); ?>

        </div>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.instructor', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/rishikumar/Desktop/developement/wavedriving/resources/views/instructor/clients/index.blade.php ENDPATH**/ ?>