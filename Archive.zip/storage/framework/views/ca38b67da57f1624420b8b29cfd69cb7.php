<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-10">
            <!-- Booking Steps -->
            <div class="booking-steps">
                <div class="step-indicator mb-4">
                    <div class="step completed">
                        <div class="step-number">1</div>
                        <div class="step-title">Suburb</div>
                    </div>
                    <div class="step completed">
                        <div class="step-number">2</div>
                        <div class="step-title">Instructor</div>
                    </div>
                    <div class="step active">
                        <div class="step-number">3</div>
                        <div class="step-title">Date & Time</div>
                    </div>
                    <div class="step">
                        <div class="step-number">4</div>
                        <div class="step-title">Service</div>
                    </div>
                    <div class="step">
                        <div class="step-number">5</div>
                        <div class="step-title">Details</div>
                    </div>
                    <div class="step">
                        <div class="step-number">6</div>
                        <div class="step-title">Payment</div>
                    </div>
                </div>

                <div class="booking-card shadow-lg rounded-4 p-0 bg-white">
                    <div class="card-header bg-primary text-white rounded-top-4 px-4 py-3">
                        <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
                            <h5 class="mb-0 fw-bold">Available Times with <?php echo e($instructor->user->name); ?></h5>
                            <div>
                                <a href="<?php echo e(route('booking.availability', [
                                    'instructor' => $instructor->id,
                                    'week_start' => $startDate->format('Y-m-d'),
                                    'direction' => 'prev'
                                ])); ?>" class="btn btn-sm btn-light fw-semibold me-2">← Previous Week</a>
                                
                                <a href="<?php echo e(route('booking.availability', [
                                    'instructor' => $instructor->id,
                                    'week_start' => $startDate->format('Y-m-d'),
                                    'direction' => 'next'
                                ])); ?>" class="btn btn-sm btn-light fw-semibold">Next Week →</a>
                            </div>
                        </div>
                    </div>

                    <div class="card-body p-4">
                        <div class="mb-3" style="max-width: 300px;">
                            <label for="service-select" class="form-label fw-semibold">Select Service</label>
                            <select id="service-select" class="form-select">
                                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($service->id); ?>" data-duration="<?php echo e($service->duration); ?>">
                                        <?php echo e($service->name); ?> (<?php echo e($service->duration); ?> min)
                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="table-responsive">
                            <table class="table table-bordered align-middle mb-0" id="availability-table">
                                <thead>
                                    <tr>
                                        <th class="bg-light text-secondary">Time</th>
                                        <?php for($date = clone $startDate; $date <= $endDate; $date->addDay()): ?>
                                            <th class="text-center <?php echo e($date->isToday() ? 'table-primary' : ''); ?>">
                                                <span class="fw-bold"><?php echo e($date->format('D')); ?></span><br>
                                                <span class="text-secondary"><?php echo e($date->format('M d')); ?></span>
                                            </th>
                                        <?php endfor; ?>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $timeSlots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="align-middle fw-semibold text-secondary">
                                                <?php echo e($slot['label']); ?>

                                            </td>
                                            <?php for($date = clone $startDate; $date <= $endDate; $date->addDay()): ?>
                                                <?php
                                                    $dateStr = $date->format('Y-m-d');
                                                    $cellTime = $slot['start']; // e.g. "06:30"
                                                    $isAvailable = isset($availabilitySlots[$dateStr]) && $availabilitySlots[$dateStr]->contains(function($s) use ($cellTime) {
                                                        return \Carbon\Carbon::parse($s->start_time)->format('H:i') === $cellTime;
                                                    });
                                                    $isBooked = isset($existingBookings[$dateStr]) &&
                                                        $existingBookings[$dateStr]->contains(function($booking) use ($cellTime) {
                                                            return \Carbon\Carbon::parse($booking->start_time)->format('H:i') === $cellTime;
                                                        });
                                                ?>
                                                <td class="text-center slot-cell <?php echo e($isAvailable && !$isBooked ? '' : 'bg-secondary'); ?>"
                                                    data-date="<?php echo e($dateStr); ?>"
                                                    data-time="<?php echo e($cellTime); ?>">
                                                    <?php if($isAvailable && !$isBooked): ?>
                                                        Available
                                                    <?php elseif($isBooked): ?>
                                                        <span class="badge bg-danger">Booked</span>
                                                    <?php else: ?>
                                                        Unavailable
                                                    <?php endif; ?>
                                                </td>
                                            <?php endfor; ?>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('styles'); ?>
<style>
    .highlight-red {
        background-color: #ffcccc !important;
        color: #b91c1c !important;
        font-weight: bold;
    }
    .bg-secondary {
        background-color: #e2e8f0 !important;
        color: #888 !important;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const serviceSelect = document.getElementById('service-select');
    const table = document.getElementById('availability-table');
    const slotCells = table.querySelectorAll('.slot-cell');

    function clearHighlights() {
        slotCells.forEach(cell => cell.classList.remove('highlight-red'));
    }

    function highlightSlots(duration) {
        const slotsNeeded = duration / 15;
        // For each column (date)
        const dates = [...new Set(Array.from(slotCells).map(cell => cell.getAttribute('data-date')))];
        dates.forEach(date => {
            // Get all cells for this date (column)
            const columnCells = Array.from(table.querySelectorAll(`td[data-date="${date}"]`));
            for (let i = 0; i <= columnCells.length - slotsNeeded; i++) {
                // Check if all needed slots are available
                let canHighlight = true;
                for (let j = 0; j < slotsNeeded; j++) {
                    const cell = columnCells[i + j];
                    if (!cell || cell.textContent.trim() !== 'Available') {
                        canHighlight = false;
                        break;
                    }
                }
                if (canHighlight) {
                    for (let j = 0; j < slotsNeeded; j++) {
                        columnCells[i + j].classList.add('highlight-red');
                    }
                }
            }
        });
    }

    serviceSelect.addEventListener('change', function() {
        clearHighlights();
        const selected = serviceSelect.options[serviceSelect.selectedIndex];
        const duration = parseInt(selected.getAttribute('data-duration'), 10);
        if (duration) {
            highlightSlots(duration);
        }
    });

    // Initial highlight
    serviceSelect.dispatchEvent(new Event('change'));
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/rishikumar/Desktop/developement/wavedriving/resources/views/booking/services.blade.php ENDPATH**/ ?>