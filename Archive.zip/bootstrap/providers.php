<?php

return [
    App\Providers\AppServiceProvider::class,
    Illuminate\Foundation\Providers\ConsoleSupportServiceProvider::class,  // ← add this
];