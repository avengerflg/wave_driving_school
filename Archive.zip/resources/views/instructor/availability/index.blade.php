@extends('layouts.instructor')

@section('title', 'Manage Availability')

@section('content')
<div class="row">
    <div class="col-12">
        <div class="card mb-4">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0"><i class="bx bx-calendar me-2"></i>Manage Availability</h5>
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#add-availability-modal">
                    <i class="bx bx-plus me-1"></i> Add Availability
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Calendar Navigation -->
<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">{{ $viewMonth->format('F Y') }}</h5>
                    <div>
                        <a href="{{ route('instructor.calendar.availability', ['month' => $prevMonth]) }}" class="btn btn-outline-primary me-2">
                            <i class="bx bx-chevron-left"></i> Previous
                        </a>
                        <a href="{{ route('instructor.calendar.availability') }}" class="btn btn-outline-primary me-2">Today</a>
                        <a href="{{ route('instructor.calendar.availability', ['month' => $nextMonth]) }}" class="btn btn-outline-primary">
                            Next <i class="bx bx-chevron-right"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Calendar View -->
<div class="row">
    @foreach($weeks as $days)
        <div class="col-12 mb-4">
            <div class="card shadow-sm">
                <div class="row g-0">
                    @foreach($days as $day)
                        @php
                            $dateStr = $day->format('Y-m-d');
                            $dayAvailabilities = $groupedAvailabilities[$dateStr] ?? collect();
                            $isToday = $day->isToday();
                            $isPast = $day->isPast() && !$isToday;
                            $isCurrentMonth = $day->month === $viewMonth->month;
                        @endphp
                        <div class="col border-end {{ !$isCurrentMonth ? 'bg-light' : '' }}">
                            <div class="p-3">
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <div>
                                        <span class="d-block {{ $isToday ? 'text-primary fw-bold' : '' }}">
                                            {{ $day->format('D') }}
                                        </span>
                                        <span class="fs-4 {{ $isPast ? 'text-muted' : ($isToday ? 'text-primary fw-bold' : '') }}">
                                            {{ $day->format('d') }}
                                        </span>
                                    </div>
                                    @if(!$isPast)
                                        <button type="button" 
                                                class="btn btn-sm btn-outline-primary rounded-circle"
                                                data-bs-toggle="modal"
                                                data-bs-target="#add-availability-modal"
                                                data-date="{{ $dateStr }}">
                                            <i class="bx bx-plus"></i>
                                        </button>
                                    @endif
                                </div>

                                <div class="availability-slots" style="min-height: 100px; max-height: 300px; overflow-y: auto;">
    @if($dayAvailabilities->count() > 0)
        @php
            // Group continuous slots
            $groupedSlots = [];
            $currentGroup = null;
            
            foreach($dayAvailabilities->sortBy('start_time') as $slot) {
                $startTime = \Carbon\Carbon::parse($slot->start_time);
                $endTime = \Carbon\Carbon::parse($slot->end_time);
                
                if ($currentGroup === null) {
                    $currentGroup = [
                        'start' => $startTime,
                        'end' => $endTime,
                        'slots' => [$slot],
                        'has_bookings' => $slot->isBooked()
                    ];
                } elseif ($currentGroup['end']->eq($startTime) && $currentGroup['has_bookings'] == $slot->isBooked()) {
                    // Continuous slot
                    $currentGroup['end'] = $endTime;
                    $currentGroup['slots'][] = $slot;
                } else {
                    // New group
                    $groupedSlots[] = $currentGroup;
                    $currentGroup = [
                        'start' => $startTime,
                        'end' => $endTime,
                        'slots' => [$slot],
                        'has_bookings' => $slot->isBooked()
                    ];
                }
            }
            if ($currentGroup !== null) {
                $groupedSlots[] = $currentGroup;
            }
        @endphp
        
        @foreach($groupedSlots as $group)
            <div class="card border-0 shadow-sm mb-2 {{ $group['has_bookings'] ? 'border-warning' : '' }}">
                <div class="card-body p-2">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <span class="small {{ $group['has_bookings'] ? 'text-warning' : '' }}">
                                {{ $group['start']->format('H:i') }} - 
                                {{ $group['end']->format('H:i') }}
                            </span>
                            @if($group['has_bookings'])
                                <span class="badge bg-warning ms-1">Booked</span>
                            @else
                                <span class="badge bg-success ms-1">Available</span>
                            @endif
                        </div>
                        @if(!$group['has_bookings'])
                            <button type="button" 
                                    class="btn btn-sm btn-icon btn-outline-danger"
                                    onclick="deleteTimeRange('{{ $dateStr }}', '{{ $group['start']->format('H:i') }}', '{{ $group['end']->format('H:i') }}')">
                                <i class="bx bx-trash"></i>
                            </button>
                        @endif
                    </div>
                </div>
            </div>
        @endforeach
    @else
        @if(!$isPast && $isCurrentMonth)
            <div class="text-center text-muted small py-3">
                <i class="bx bx-calendar-x mb-1"></i>
                <p class="mb-0">No availability</p>
            </div>
        @endif
    @endif
</div>
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>
    @endforeach
</div>

<!-- Add Availability Modal -->
<div class="modal fade" id="add-availability-modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="{{ route('instructor.availability.store') }}" method="POST">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title">Add Availability</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Date</label>
                        <input type="date" name="date" class="form-control" required min="{{ now()->format('Y-m-d') }}" value="{{ now()->format('Y-m-d') }}">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Service</label>
                        <select name="service_id" id="service_id" class="form-select" required>
                            <option value="">Select Service</option>
                            @foreach($services as $service)
                                <option value="{{ $service->id }}" data-duration="{{ $service->duration }}">
                                    {{ $service->name }} ({{ $service->duration }} min)
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Start Time</label>
                            <input type="time" name="start_time" id="start_time" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">End Time</label>
                            <input type="time" name="end_time" id="end_time" class="form-control" required readonly>
                        </div>
                    </div>
                    <!-- Recurring options as before -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Add Availability</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection

@section('page-scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    const serviceSelect = document.getElementById('service_id');
    const startTimeInput = document.getElementById('start_time');
    const endTimeInput = document.getElementById('end_time');

    function updateEndTime() {
        const selected = serviceSelect.options[serviceSelect.selectedIndex];
        const duration = parseInt(selected.getAttribute('data-duration'), 10);
        const startTime = startTimeInput.value;
        if (duration && startTime) {
            const [hours, minutes] = startTime.split(':').map(Number);
            const start = new Date(0, 0, 0, hours, minutes);
            start.setMinutes(start.getMinutes() + duration);
            const endHours = String(start.getHours()).padStart(2, '0');
            const endMinutes = String(start.getMinutes()).padStart(2, '0');
            endTimeInput.value = `${endHours}:${endMinutes}`;
        } else {
            endTimeInput.value = '';
        }
    }

    serviceSelect.addEventListener('change', updateEndTime);
    startTimeInput.addEventListener('change', updateEndTime);
});
</script>

<style>
    .availability-slots {
        max-height: 200px;
        overflow-y: auto;
    }

    .btn-check:checked + .btn-outline-primary {
        background-color: #696cff;
        color: #fff;
    }
</style>
@endsection